#include <iostream>
#include <string>
using namespace std;

struct Contacto {
    string nombre;
    string telefono;
    string correo;
};

Contacto arr[100];
int total = 0;

struct Nodo {
    Contacto dato;
    Nodo* sig;
};

Nodo* cabeza = NULL;

void agregarLista(Contacto c) {
    Nodo* nuevo = new Nodo();
    nuevo->dato = c;
    nuevo->sig = cabeza;
    cabeza = nuevo;
}

bool eliminarLista(string nombre) {
    if (cabeza == NULL) return false;

    if (cabeza->dato.nombre == nombre) {
        Nodo* t = cabeza;
        cabeza = cabeza->sig;
        delete t;
        return true;
    }

    Nodo* act = cabeza;
    Nodo* ant = NULL;

    while (act != NULL && act->dato.nombre != nombre) {
        ant = act;
        act = act->sig;
    }

    if (act == NULL) return false;

    ant->sig = act->sig;
    delete act;
    return true;
}

struct NodoArbol {
    Contacto dato;
    NodoArbol* izq;
    NodoArbol* der;
    NodoArbol(Contacto c) {
        dato = c;
        izq = NULL;
        der = NULL;
    }
};

NodoArbol* raiz = NULL;

NodoArbol* insertar(NodoArbol* r, Contacto c) {
    if (r == NULL) return new NodoArbol(c);
    if (c.nombre < r->dato.nombre)
        r->izq = insertar(r->izq, c);
    else
        r->der = insertar(r->der, c);
    return r;
}

void inorden(NodoArbol* r) {
    if (r == NULL) return;
    inorden(r->izq);
    cout << r->dato.nombre << " - " << r->dato.telefono << endl;
    inorden(r->der);
}

void preorden(NodoArbol* r) {
    if (r == NULL) return;
    cout << r->dato.nombre << " - " << r->dato.telefono << endl;
    preorden(r->izq);
    preorden(r->der);
}

void listar() {
    if (total == 0) {
        cout << "No hay contactos.\n";
        return;
    }
    for (int i = 0; i < total; i++)
        cout << arr[i].nombre << " - " << arr[i].telefono << " - " << arr[i].correo << endl;
}

int main() {
    int op;

    do {
        cout << "\n1 Agregar contacto\n2 Listar\n3 Eliminar\n4 Ver arbol (inorden)\n5 Ver arbol (preorden)\n0 Salir\nOpcion: ";
        cin >> op;
        cin.ignore();

        if (op == 1) {
            Contacto c;
            cout << "Nombre: "; getline(cin, c.nombre);
            cout << "Telefono: "; getline(cin, c.telefono);
            cout << "Correo: "; getline(cin, c.correo);
            arr[total] = c;
            total++;
            agregarLista(c);
            raiz = insertar(raiz, c);
        }

        else if (op == 2) {
            listar();
        }

        else if (op == 3) {
            string n;
            cout << "Nombre a eliminar: ";
            getline(cin, n);
            if (eliminarLista(n)) cout << "Eliminado.\n";
            else cout << "No existe.\n";
        }

        else if (op == 4) {
            inorden(raiz);
        }

        else if (op == 5) {
            preorden(raiz);
        }

    } while (op != 0);

    return 0;
}